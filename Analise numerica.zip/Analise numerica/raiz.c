#include "raiz.h"
#include "stdio.h"
#include <math.h>

#define TOL 0.0000000000000001

int bissecao (double a, double b, int p, double (*f) (double x), double* r)
{
    double fa=f(a);
    double fb=f(b);
    double c = (a+b)/2.0;
    double fc;
    double max_error = 0.5*pow(10,-p);
    int iters = ceil(log2(fabs(b-a)/max_error))-1;
    int i;
    printf("%d\n",iters);
    for(i=0; i<iters; i++)
    {
        fc = f(c);
        if(fabs(fc) < TOL)
        {
            break;
        }

        if((fa*fc) < 0)
        {
            b=c;
            fb=fc;
        }
        else
        {
            a=c;
            fa=fc;
        }
        c=(a+b)/2.0;

    }
    *r=(a+b)/2.0;
    return i;
}
