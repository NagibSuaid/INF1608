#include "raiz.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>

double myFunc(double x)
{
    return exp(x)-5;
}

int main()
{
    double r;

    int its = bissecao(0.0,5.0,5,myFunc,&r);
    printf("Raiz encontrada: %g\nIteracoes: %d\n",r,its);
}